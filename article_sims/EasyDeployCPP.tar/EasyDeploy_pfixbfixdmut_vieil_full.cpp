#ifdef _OPENMP
#include <omp.h>
#endif
#include <algorithm>
#include <iostream>
#include <sstream>
#include <cstdio>
#include <random>
#include <chrono>
#include <ctime>
#include <sys/stat.h>

constexpr float intensite_naissance   = 1.0;
constexpr float intensite_mort        = 1.0;
constexpr float intensite_competition = 5.0e-4;
constexpr float t_mut                 = 0.05;
constexpr float var_mut               = 0.05;
constexpr float intmax                = intensite_naissance + intensite_mort + intensite_competition;
constexpr unsigned short tir          = 1;
constexpr unsigned short nb           = 10;
#define nombre_saut                     5000000
#define taille_population               100000
#define M                               8

#define COL_MAJ 1

#if COL_MAJ
#define IDX(i, j, n, m) (i + j * n)
#else
#define IDX(i, j, n, m) (i * m + j)
#endif

/*
constexpr float bmin = 4.1;
constexpr float bmax = 5.0;
constexpr float pasb = 0.2;
constexpr float dmin = 0.0;
constexpr float dmax = 10.0;
constexpr float pasd = 0.2;
*/

inline void trait_herite(float* x, float u, float* y) {
    if(x[1] > 0.0 && u >= x[1]) {
        y[0] = x[0];
        y[1] = 0.0f;
    }
    else
        std::copy_n(x, 2, y);
}
inline float dm(float x, float var_mut) {
    std::random_device rd;
    std::default_random_engine generator(rd());
    std::normal_distribution<float> d(0.0, var_mut);
    float g = d(generator);
    while(x + g < 0.0f)
        g = d(generator);
    return x + g;
}
inline float b(float* x, float a) {
    return (a <= x[0]) ? intensite_naissance : 0.0f;
}
inline float d(float* x, float a) {
    return (a > x[1]) ? intensite_mort : 0.0f;
}

inline float acceptation_rejet_clone(float* t, float a, int n) {
    return b(t, a) * (1 - t_mut) / (intmax * n);
}
inline float acceptation_rejet_mutant(float* t, float a, int n) {
    return acceptation_rejet_clone(t, a, n) + (b(t, a) * t_mut) / (intmax * n);
}
inline float acceptation_rejet_mort(float* t, float a, int n) {
    return acceptation_rejet_mutant(t, a, n) + (d(t, a) + (n - 1) * intensite_competition) / (intmax * n);
}

inline unsigned short tirage(float intmax, int np, int mp, float* p, float intensite_competition, float intensite_mort, float intensite_naissance, float t_mut, float* output, float var_mut, int* s, float* p05) {
    float* viv;
    int nv;
    {
        std::vector<int> idx;
        idx.reserve(np);
        for(int i = 0; i < np; ++i) {
            if(std::abs(p[IDX(i, 2, np, mp)] - 1.0f) < 1.0e-6)
                idx.emplace_back(i);
        }
        nv = idx.size();
        viv = new float[mp * nv];
        int pos = 0;
#if COL_MAJ
        for(int j = 0; j < mp; ++j) {
            for(int i = 0; i < nv; ++i) {
#else
        for(int i = 0; i < nv; ++i) {
            for(int j = 0; j < mp; ++j) {
#endif
                viv[pos++] = p[IDX(idx[i], j, np, mp)];
            }
        }
    }
    std::random_device rd;
    std::default_random_engine generator(rd());
    std::exponential_distribution<float> d(1.0f);
    std::uniform_int_distribution<int> randint(0, nv - 1);
    std::uniform_real_distribution<float> uniform(0.0f, 1.0f);
    float u = uniform(generator);
    float temps_maximal = d(generator) / (intmax * nv * nv);
   while(std::isinf(temps_maximal))
        temps_maximal = d(generator) / (intmax * nv * nv);
    int ind = randint(generator);
    float w = *p05 - viv[IDX(ind, 3, nv, mp)] + temps_maximal;
    float rows[2] = { viv[IDX(ind, 0, nv, mp)], viv[IDX(ind, 1, nv, mp)] };
    while(u > acceptation_rejet_mort(rows, w, nv)) {
        float v = d(generator);
        while(std::isinf(v))
            v = d(generator);
        temps_maximal += v / (intmax * nv * nv);
        u = uniform(generator);
        ind = randint(generator);
        w = *p05 - viv[IDX(ind, 3, nv, mp)] + temps_maximal;
        rows[0] = viv[IDX(ind, 0, nv, mp)]; rows[1] = viv[IDX(ind, 1, nv, mp)];
    }
    float a[4] = { (w > rows[1] ? 1.0f : 0.0f), acceptation_rejet_clone(rows, w, nv), acceptation_rejet_mutant(rows, w, nv), acceptation_rejet_mort(rows, w, nv) };
    trait_herite(rows, w, output);
    unsigned short vstack = 0;
    if(u <= a[1])
        vstack = 1;
    else if(u <= a[2]) {
        output[1] = dm(output[1], var_mut);
        vstack = 1;
    }
    else if(u <= a[3]) {
        *s = 0;
        for(int i = 0; i < np; ++i) {
            if(p[IDX(i, 5, np, mp)] == viv[IDX(ind, 5, nv, mp)]) {
                p[IDX(i, 2, np, mp)] = 0.0;
                p[IDX(i, 4, np, mp)] = *p05 + temps_maximal;
            }
            else
                *s += int(p[IDX(i, 2, np, mp)]);
        }
        vstack = 2;
    }
    output[2] = 1.0;
    *p05 += temps_maximal;
    output[3] = *p05;
    output[4] = 0.0;
    output[5] = p[IDX((np - 1), 5, np, mp)] + 1;
    output[6] = viv[IDX(ind, 5, nv, mp)];
    output[7] = a[0];
    // output[8] = viv[IDX(ind, 8, nv, mp)];
    if(vstack != 2) {
        *s = vstack;
        for(int i = 0; i < np; ++i)
            *s += int(p[IDX(i, 2, np, mp)]);
    }
    delete [] viv;
    return vstack;
}
inline void init(unsigned short tirage, float* population_0, int t, int mp) {
    std::random_device rd;
    std::default_random_engine generator(rd());
    std::uniform_real_distribution<float> rand_b(-10.0f, 10.0f);
    std::uniform_real_distribution<float> rand_d(0.0f, 10.0f);
    for(int k = 0; k < t; ++k) {
        float u = rand_b(generator);
        float b = rand_d(generator);
        while(b - u > 10.0f || b - u < 0.0f)
            b = rand_d(generator);
        population_0[IDX(k, 0, t, mp)] = b;
        population_0[IDX(k, 1, t, mp)] = b - u;
        population_0[IDX(k, 2, t, mp)] = 1;
        population_0[IDX(k, 5, t, mp)] = k + 1;
        // population_0[IDX(k, 8, t, mp)] = 1;
    }
}
inline void save(unsigned short tirage, float intensite_competition, float t_mut, float var_mut, int ns, int t, int n, float* A, float p05, unsigned short nb) {
    std::ostringstream ss;
    ss << "bfdm,c=" << intensite_competition << ",p=" << t_mut << ",v=" << var_mut << ",ns=" << ns << ",tp=" << t << ",tirage=" << tir << "_" << nb << ".csv";
    FILE* f = std::fopen(ss.str().c_str(), "w");
    std::fprintf(f, "b;d;etat;t naissance;t mort;ind id;parent id;parent sen;%f\n", p05);
    // std::fprintf(f, "b;d;etat;t naissance;t mort;%f;ind id;parent id;parent sen;numero sous pop\n", p05);
    for(int i = 0; i < n; ++i)
        std::fprintf(f, "%f;%f;%d;%f;%f;%d;%d;%d\n", A[IDX(i, 0, n, M)], A[IDX(i, 1, n, M)], int(A[IDX(i, 2, n, M)]), A[IDX(i, 3, n, M)], A[IDX(i, 4, n, M)], int(A[IDX(i, 5, n, M)]), int(A[IDX(i, 6, n, M)]), int(A[IDX(i, 7, n, M)]));
        // std::fprintf(f, "%f;%f;%d;%f;%f;%d;%d;%d;%d\n", A[IDX(i, 0, n, M)], A[IDX(i, 1, n, M)], int(A[IDX(i, 2, n, M)]), A[IDX(i, 3, n, M)], A[IDX(i, 4, n, M)], int(A[IDX(i, 5, n, M)]), int(A[IDX(i, 6, n, M)]), int(A[IDX(i, 7, n, M)]), int(A[IDX(i, 8, n, M)]));
    std::fclose(f);
}
inline void trajectoire(float** population, int np, int* final, float* p05) {
    int n = 0;
    for(int i = 0; i < np; ++i)
        n += int((*population)[IDX(i, 2, np, M)]);
    for(int cs = 0; cs < nombre_saut && n >= 1; ++cs) {
        float* output = new float[M];
        unsigned short vstack = tirage(intmax, *final, M, *population, intensite_competition, intensite_mort, intensite_naissance, t_mut, output, var_mut, &n, p05);
        if(vstack == 1) {
            float* new_population = new float[(*final + 1) * M]();
#if COL_MAJ
            for(int i = 0; i < M; ++i) {
                std::copy_n(*population + i * *final, *final, new_population + i * (*final + 1));
                new_population[(i + 1) * (*final + 1) - 1] = output[i];
            }
#else
            std::copy_n(*population, M * *final, new_population);
            std::copy_n(output, M, new_population + M * *final);
#endif
            delete [] *population;
            *population = new_population;
            (*final)++;
        }
        delete [] output;
    }
    for(int i = 0; i < *final; ++i)
        if(std::abs((*population)[IDX(i, 4, *final, M)]) < 1.0e-6)
            (*population)[IDX(i, 4, *final, M)] = *p05;
}

int main(int argc, char** argv) {
    for(unsigned short i = 0; i < nb; ++i) {
//     const int steps_b = std::ceil((bmax - bmin) / pasb);
//     const int steps_d = std::ceil((dmax - dmin) / pasd);
// #ifdef _OPENMP
// #pragma omp parallel for schedule(guided, 4) collapse(2)
// #endif
//     for(int i = 0; i < steps_b; ++i) {
//         for(int j = 0; j < steps_d; ++j) {
//             const float b = bmin + i * pasb;
//             const float d = dmin + j * pasb;
//             if(!skip(b, d, intensite_competition, t_mut, var_mut, nombre_saut, taille_population)) {
                std::chrono::time_point<std::chrono::system_clock> start, end;
                start = std::chrono::system_clock::now();
                float p05 = 0.0f;
                float* population_0 = new float[taille_population * M]();
                init(tir, population_0, taille_population, M);
                int final = taille_population;
                trajectoire(&population_0, taille_population, &final, &p05);
                save(tir, intensite_competition, t_mut, var_mut, nombre_saut, taille_population, final, population_0, p05, i);
                delete [] population_0;
                end = std::chrono::system_clock::now();

                std::chrono::duration<double> elapsed_seconds = end - start;
                std::time_t end_time = std::chrono::system_clock::to_time_t(end);

                std::cout << "finished computation at " << std::ctime(&end_time) << "elapsed time: " << elapsed_seconds.count() << "s (tirage=" << tir << ")\n";
//            }
//            else
//                std::cout << "skipped computation (b=" << b << ",d=" << d << ")\n";
//        }
//     }
    }
    return 0;
}
